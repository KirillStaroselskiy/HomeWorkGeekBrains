//
//  PhotoCollectionCell.swift
//  HomeWorkGeekBrains
//
//  Created by Kirill on 05/12/2018.
//  Copyright © 2018 Kirill. All rights reserved.
//

import UIKit

class PhotoCollectionCell: UICollectionViewCell {
    

    @IBOutlet weak var photoFriend: UIImageView!
}
