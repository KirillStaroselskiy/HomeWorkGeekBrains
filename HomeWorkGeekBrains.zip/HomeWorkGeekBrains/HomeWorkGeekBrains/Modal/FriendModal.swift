//
//  FriendModal.swift
//  HomeWorkGeekBrains
//
//  Created by Kirill on 05/12/2018.
//  Copyright © 2018 Kirill. All rights reserved.
//

import UIKit


class FriendModal {
    
    var name: String!
    var image: String!
    
    init(name: String, image: String) {
        self.name = name
        self.image = image
    }
    
    
}
